package com.example.prac2;

import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.math.MathUtils;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link Spending#newInstance} factory method to
 * create an instance of this fragment.
 */
public class Spending extends Fragment {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public Spending() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment Spending.
     */
    // TODO: Rename and change types and number of parameters
    public static Spending newInstance(String param1, String param2) {
        Spending fragment = new Spending();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        btnIncome = (Button) view.findViewById(R.id.btnIncome);
        btnExpence = (Button) view.findViewById(R.id.btnExpence);
        btnIncome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(getActivity(),incomeInsert.class);
                startActivity(intent);

            }
        });
        btnExpence.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(getActivity(),insertExpence.class);
                startActivity(intent);

            }
        });
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_spending, container, false);
    }
    TextView txt1,txt2,txt3,txt4;
    Button btnIncome,btnExpence;
    public void onStart() {
        super.onStart();
        //txt=(TextView)getActivity().findViewById(R.id.textView2);
        Item i = new Item();
        ItemDatabase id = ItemDatabase.getAppDatabase(getContext());
        ItemDao dao = id.itemDao();
        //get all users
        List<Item> items = dao.getAllIncome();
        int sum_inc=0;
        String all_exp="";
        for (Item e : items) {
            sum_inc+=Integer.parseInt(e.getItemPrice());
        }
        List<Item> items_ex = dao.getAllExpences();
        int sum_exp=0;
        int bal;
        for (Item e : items_ex) {
            sum_exp+=Integer.parseInt(e.getItemPrice());
            all_exp+=String.valueOf(e.getItemName());
            all_exp+="\t";
            all_exp+=String.valueOf(e.getItemPrice());
            all_exp+="\n";
        }
        bal=sum_inc-sum_exp;
        ProgressBar progress = getActivity().findViewById(R.id.simpleProgressBar);
        progress.setMax(sum_inc);
        progress.setProgress(bal);
        txt1 = getActivity().findViewById(R.id.total_inc);
        txt1.setText(String.valueOf(sum_inc));
        txt2 = getActivity().findViewById(R.id.total_exp);
        txt2.setText(String.valueOf(sum_exp));
        txt3 = getActivity().findViewById(R.id.all_exp);
        txt3.setText(all_exp);
        txt4 = getActivity().findViewById(R.id.total_balance);
        txt4.setText(String.valueOf(bal));
        //Toast.makeText(getActivity().getApplicationContext(), sum, Toast.LENGTH_SHORT).show();
    }
    }