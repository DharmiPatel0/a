package com.example.prac2;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class ottp extends AppCompatActivity {
    Button btn1;
    EditText otpEntered;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_otp);
        btn1 = (Button) findViewById(R.id.button2);
        otpEntered = (EditText) findViewById(R.id.editTextNumber);
        String otpEnt = otpEntered.toString();
        SharedPreferences sharedPreferences = getSharedPreferences("MySharedPref",MODE_PRIVATE);
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                /*String realOTP = sharedPreferences.getString("OTP", "");
                if (realOTP==otpEnt){
                    Intent fp=new Intent(getApplicationContext(),Dashboard.class);
                    startActivity(fp);
                }*/
                Intent intent=new Intent(getApplicationContext(),navigationActDashboard.class);
                startActivity(intent);


            }
        });
    }
}