package com.example.prac2;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.TextView;

import com.example.prac2.RView.CateData;
import com.example.prac2.RView.CateListAdapter;

import java.util.ArrayList;
import java.util.List;

public class viewData extends AppCompatActivity {
    CateListAdapter cateListAdapter;
    RecyclerView recyclerView;
    TextView txt;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_data);
        txt=(TextView)findViewById(R.id.textView2);
        categoryTbl i = new categoryTbl();
        ItemDatabase id = ItemDatabase.getAppDatabase(getApplicationContext());
        ItemDao dao = id.itemDao();
        //get all users
        List<categoryTbl> cats = dao.getAllcats();
        List<String> l=new ArrayList();
        for(categoryTbl e : cats) {
            l.add(e.getItemName());
        }
        //txt.setText(String.valueOf(items.size()));
        //get single user by id
        recyclerView = findViewById(R.id.listContainer);
        /*for(int j=1;j<=items.size();j++){
            new CateData(R.drawable.book,l.get(j).toString());
        }*/

        CateData[] myListData = new CateData[cats.size()];
        int k=0;
        for(categoryTbl e : cats) {
            myListData[k]=new CateData(R.drawable.book,e.getItemName());
            k++;
        }
        LinearLayoutManager layoutManager = new LinearLayoutManager(getApplicationContext());
        layoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        recyclerView.setLayoutManager(layoutManager);
        cateListAdapter = new CateListAdapter(myListData);
        recyclerView.setHasFixedSize(true);
        recyclerView.setAdapter(cateListAdapter);
    }
}