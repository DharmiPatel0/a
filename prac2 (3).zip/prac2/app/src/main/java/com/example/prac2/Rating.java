package com.example.prac2;

import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RatingBar;
import android.widget.Toast;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link Rating#newInstance} factory method to
 * create an instance of this fragment.
 */
public class Rating extends Fragment {
    RatingBar ratingbar;
    Button button;
    EditText cmt;
    String emailsend ="niralijasoliya2000@gmail.com";
    String emailsubject="Comments";
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public Rating() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment Rating.
     */
    // TODO: Rename and change types and number of parameters
    public static Rating newInstance(String param1, String param2) {
        Rating fragment = new Rating();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        addListenerOnButtonClick();
    }
        @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_rating, container, false);
    }
    public void addListenerOnButtonClick(){
        ratingbar=(RatingBar)getActivity().findViewById(R.id.ratingBar);
        button=(Button)getActivity().findViewById(R.id.btnsend);
        cmt=(EditText)getActivity().findViewById(R.id.txtComment);
        //Performing action on Button Click
        button.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View arg0) {
                //Getting the rating and displaying it on the toast
                String rating=String.valueOf(ratingbar.getRating());
                Toast.makeText(getContext(), rating, Toast.LENGTH_LONG).show();
                String emailbody = cmt.getText().toString();
                Intent intent = new Intent(Intent.ACTION_SEND);
                emailbody+="\nRate from my side is "+rating;
                // add three fiels to intent using putExtra function
                intent.putExtra(Intent.EXTRA_EMAIL, new String[] { emailsend });
                intent.putExtra(Intent.EXTRA_SUBJECT, emailsubject);
                intent.putExtra(Intent.EXTRA_TEXT, emailbody);
                // set type of intent
                intent.setType("message/rfc822");
                // startActivity with intent with chooser
                // as Email client using createChooser function
                startActivity(
                        Intent
                                .createChooser(intent,
                                        "Choose an Email client :"));
            }
        });
    }
}