package com.example.prac2.RView;

public class CateData {
    private int imgid;
    private String category;
    public CateData(int imgid,String category){
        this.imgid = imgid;
        this.category = category;
    }

    public int getImgid() {
        return imgid;
    }

    public void setImgid(int imgid) {
        this.imgid = imgid;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }
}
