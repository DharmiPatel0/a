package com.example.prac2;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class AddCategories extends AppCompatActivity {
    Button btn1;
    EditText name;
    public static final String Item_ADDED = "new_item";
    RadioGroup radioGroup;
    RadioButton selectedRadioButton;
    String selectedRbText;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_categories);
        btn1 = (Button) findViewById(R.id.button);
        radioGroup = (RadioGroup) findViewById(R.id.rg);
        name = (EditText) findViewById(R.id.catname);
        //price=(EditText)findViewById(R.id.catprice);
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int selectedRadioButtonId = radioGroup.getCheckedRadioButtonId();
                if (selectedRadioButtonId != -1) {
                    selectedRadioButton = findViewById(selectedRadioButtonId);
                    selectedRbText = selectedRadioButton.getText().toString();
                    ItemDatabase id = ItemDatabase.getAppDatabase(getApplicationContext());
                    categoryTbl i = new categoryTbl();
                    i.setItemName(name.getText().toString());
                    i.setItemCat(selectedRbText);
//init dao and perform operation
                    ItemDao dao = id.itemDao();
                    dao.insertCat(i);
                    Toast.makeText(getApplicationContext(), selectedRbText, Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(getApplicationContext(), "Not done", Toast.LENGTH_SHORT).show();
                }
                Intent intent = new Intent(getApplicationContext(), viewData.class);
                startActivity(intent);
            }
        });
    }
}