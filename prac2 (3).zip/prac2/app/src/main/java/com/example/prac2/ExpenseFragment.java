package com.example.prac2;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.prac2.RView.CateData;
import com.example.prac2.RView.CateListAdapter;

import java.util.ArrayList;
import java.util.List;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link ExpenseFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class ExpenseFragment extends Fragment {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public ExpenseFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment ExpenseFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static ExpenseFragment newInstance(String param1, String param2) {
        ExpenseFragment fragment = new ExpenseFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_expense, container, false);
    }
    CateListAdapter cateListAdapter;
    RecyclerView recyclerView;
    public void onStart() {
        super.onStart();
        //txt=(TextView)getActivity().findViewById(R.id.textView2);
        categoryTbl i = new categoryTbl();
        ItemDatabase id = ItemDatabase.getAppDatabase(getContext());
        ItemDao dao = id.itemDao();
        //get all users
        List<categoryTbl> categories = dao.getAllCatExpences();
        List<String> l=new ArrayList();
        for(categoryTbl e : categories) {
            l.add(e.getItemName());
        }
        //txt.setText(String.valueOf(items.size()));
        //get single user by id
        recyclerView = getActivity().findViewById(R.id.listContainer);
        /*for(int j=1;j<=items.size();j++){
            new CateData(R.drawable.book,l.get(j).toString());
        }*/

        CateData[] myListData = new CateData[categories.size()];
        int k=0;
        for(categoryTbl e : categories) {
            myListData[k]=new CateData(R.drawable.book,e.getItemName());
            k++;
        }
        LinearLayoutManager layoutManager = new LinearLayoutManager(getContext());
        layoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        recyclerView.setLayoutManager(layoutManager);
        cateListAdapter = new CateListAdapter(myListData);
        recyclerView.setHasFixedSize(true);
        recyclerView.setAdapter(cateListAdapter);
    }
}