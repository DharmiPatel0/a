package com.example.prac2;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

@Database(entities = {Item.class,categoryTbl.class}, version = 1)
public abstract class ItemDatabase extends RoomDatabase{
        public abstract ItemDao itemDao();

        private static com.example.prac2.ItemDatabase INSTANCE;

        public static com.example.prac2.ItemDatabase getAppDatabase(Context context) {
            if (INSTANCE == null) {
                INSTANCE = Room.databaseBuilder(context.getApplicationContext(), com.example.prac2.ItemDatabase.class, "item-database").allowMainThreadQueries().build();
            }
            return INSTANCE;
        }
        public static void destroyInstance() {
            INSTANCE = null;
        }
}
