package com.example.prac2;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class incomeInsert extends AppCompatActivity implements AdapterView.OnItemSelectedListener {
    EditText price;
    Button btn1;
    List<String> cat=new ArrayList<String>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_income_insert);
        Spinner spin = (Spinner) findViewById(R.id.spinner1);
        btn1 = (Button) findViewById(R.id.button);
        price=(EditText)findViewById(R.id.catprice);
        categoryTbl i = new categoryTbl();
        ItemDatabase id = ItemDatabase.getAppDatabase(getApplicationContext());
        ItemDao dao = id.itemDao();
        List<categoryTbl> ct = dao.getAllCatIncome();
        for (categoryTbl e : ct) {
            cat.add(e.getItemName());
        }
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, cat);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spin.setAdapter(adapter);
        spin.setOnItemSelectedListener(this);
    }

    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ItemDatabase ide = ItemDatabase.getAppDatabase(getApplicationContext());
                Item it = new Item();
                it.setItemName(cat.get(i));
                it.setItemCat("Income");
                it.setItemPrice(price.getText().toString());
                ItemDao daoo = ide.itemDao();
                daoo.insert(it);
                Toast.makeText(getApplicationContext(), "Selected Item: " + cat.get(i), Toast.LENGTH_SHORT).show();
                Intent intent=new Intent(getApplicationContext(),navigationActDashboard.class);
                startActivity(intent);
            }
        });
    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }
}