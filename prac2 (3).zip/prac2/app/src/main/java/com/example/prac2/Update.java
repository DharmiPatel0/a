package com.example.prac2;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class Update extends AppCompatActivity {
    EditText phone,name,email,password,address,dob;
    Button btn1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update);
        btn1 = (Button) findViewById(R.id.button3);
        phone = (EditText) findViewById(R.id.editTextNumber2);
        name = (EditText) findViewById(R.id.editTextTextPersonName);
        email = (EditText) findViewById(R.id.editTextTextEmailAddress);
        address = (EditText) findViewById(R.id.editTextNumber3);
        dob = (EditText) findViewById(R.id.editTextDate);
        password = (EditText) findViewById(R.id.editTextTextPassword);
        SharedPreferences sharedPreferences = getSharedPreferences("MySharedPref",MODE_PRIVATE);
        String Name = sharedPreferences.getString("name", "");
        String Email = sharedPreferences.getString("email", "");
        String Phone = sharedPreferences.getString("phone", "");
        String Password = sharedPreferences.getString("password", "");
        String Address = sharedPreferences.getString("address", "");
        String Dob = sharedPreferences.getString("DOB", "");
        name.setText(Name);
        phone.setText(Phone);
        email.setText(Email);
        address.setText(Address);
        dob.setText(Dob);
        password.setText(Password);
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Toast.makeText();
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putString("name", name.getText().toString());
                editor.putString("email", email.getText().toString());
                editor.putString("address", address.getText().toString());
                editor.putString("password", password.getText().toString());
                editor.putString("phone", phone.getText().toString());
                editor.putString("DOB", dob.getText().toString());
                editor.apply();
                Intent intent=new Intent(getApplicationContext(),Update.class);
                startActivity(intent);

            }
        });

    }
}