package com.example.prac2;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class Dashboard extends AppCompatActivity {
    //Button update,logout;
    //private ViewPager viewPager;
    //private TabLayout tabLayout;
    //@RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);
    }
        /*Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        update = (Button) findViewById(R.id.update);
        logout = (Button) findViewById(R.id.logout);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        viewPager=(ViewPager) findViewById(R.id.view_pager);
        SectionsPagerAdapter adapter = new SectionsPagerAdapter(this,getSupportFragmentManager());
        viewPager.setAdapter(adapter);

        tabLayout = (TabLayout) findViewById(R.id.tabs);
        tabLayout.setupWithViewPager(viewPager);
        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                    Intent fp=new Intent(getApplicationContext(),Update.class);
                    startActivity(fp);
                }
        });
        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent fp=new Intent(getApplicationContext(),MainActivity.class);
                startActivity(fp);
            }
        });
    }

    private void setSupportActionBar(Toolbar toolbar) {
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        switch (id){
            case R.id.item1:
                Toast.makeText(getApplicationContext(),"Item 1 Selected",Toast.LENGTH_LONG).show();
                return true;
            case R.id.item2:
                Toast.makeText(getApplicationContext(),"Item 2 Selected",Toast.LENGTH_LONG).show();
                return true;
            case R.id.item3:
                Toast.makeText(getApplicationContext(),"Item 3 Selected",Toast.LENGTH_LONG).show();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }*/
}