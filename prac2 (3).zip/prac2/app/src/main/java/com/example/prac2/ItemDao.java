package com.example.prac2;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface ItemDao {
    @Insert
    Long insert(Item i);
    @Insert
    Long insertCat(categoryTbl cat);

    @Query("SELECT * FROM `Item` ORDER BY `id` DESC")
    List<Item> getAllItems();

    @Query("SELECT * FROM `categoryTbl` ORDER BY `id` DESC")
    List<categoryTbl> getAllcats();

    @Query("Select * from Item where item_category='Income'")
    List<Item> getAllIncome();

    @Query("Select * from categoryTbl where cat_category='Income'")
    List<categoryTbl> getAllCatIncome();

    @Query("Select * from Item where item_category='Expenses'")
    List<Item> getAllExpences();

    @Query("Select * from categoryTbl where cat_category='Expenses'")
    List<categoryTbl> getAllCatExpences();

    @Update
    void update(Item i);

    @Delete
    void delete(Item i);
}
