package com.example.prac2;

import android.content.Intent;
import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.tabs.TabLayout;

import androidx.appcompat.widget.Toolbar;
import androidx.viewpager.widget.ViewPager;
import androidx.appcompat.app.AppCompatActivity;

import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

import com.example.prac2.ui.main.SectionsPagerAdapter;
import com.example.prac2.databinding.ActivityMyDashboardBinding;

public class MyDashboard extends AppCompatActivity {

    private ActivityMyDashboardBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityMyDashboardBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        Toolbar tb=(Toolbar)findViewById(R.id.toolbar);
        setSupportActionBar(tb);
        SectionsPagerAdapter sectionsPagerAdapter = new SectionsPagerAdapter(this, getSupportFragmentManager());
        ViewPager viewPager = binding.viewPager;
        viewPager.setAdapter(sectionsPagerAdapter);
        TabLayout tabs = binding.tabs;
        tabs.setupWithViewPager(viewPager);
        FloatingActionButton fab = binding.fab;

        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int item_id=item.getItemId();
        switch (item.getItemId()) {
            case R.id.action_settings:  {
                return true;
            }
            case R.id.action_help: {

                return true;
            }
            case R.id.action_update: {
                startActivity(new Intent(this, Update.class));
                return true;
            }

            case R.id.action_add: {
                startActivity(new Intent(this, AddCategories.class));
                return true;
            }
            default:
                return super.onOptionsItemSelected(item);
        }
    }

}