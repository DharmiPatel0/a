package com.example.prac2;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity
public class categoryTbl {
    @PrimaryKey(autoGenerate = true)
    private int id;

    @ColumnInfo(name = "cat_name")
    private String itemName;

    @ColumnInfo(name = "cat_category")
    private String itemCat;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public String getItemCat() {
        return itemCat;
    }

    public void setItemCat(String itemCat) {
        this.itemCat = itemCat;
    }
}
