package com.example.prac2;

import androidx.fragment.app.Fragment;

public interface FragmentChangeListener {
    public void replaceFragment(Fragment fragment);
}
